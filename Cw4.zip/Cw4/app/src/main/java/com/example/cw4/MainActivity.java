package com.example.cw4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button a = findViewById(R.id.Button);
        final EditText c = findViewById(R.id.editTextTextPersonName3);
        final EditText z = findViewById(R.id.editTextTextPersonName4);
        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


               int sum = Integer.parseInt(c.getText().toString())+Integer.parseInt(z.getText().toString());
                Toast.makeText(MainActivity.this, sum+"", Toast.LENGTH_SHORT).show();

                
            }
        });

    }
}